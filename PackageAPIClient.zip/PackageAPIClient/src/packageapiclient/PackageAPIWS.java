package packageapiclient;

import java.io.*;
import java.net.*;
import java.util.*;


import com.thunderhead.ws.cms.AnnotationAPI;
import com.thunderhead.ws.cms.CMSAPI2WebServiceLocator;
import com.thunderhead.ws.cms.CMSAPI2Web;

import org.apache.axis.client.Stub;
import org.apache.axis.configuration.FileProvider;

public class PackageAPIWS {
    
    public static void main(String[] args) {
        try {
            // test args
            if (args.length < 1) {
                // args missing job-file
                System.out.println("To run this example please supply the properties file as an argument.");
                System.exit(1);
            }

            
            // load configuration settings
            System.out.println("Loading properties file: " + args[0]);
            Properties props = new Properties();
            props.load(new FileInputStream(args[0]));
            String webServiceUrl = props.getProperty("webServiceUrl");
            String username = props.getProperty("username");
            String password = props.getProperty("password");
            String inputFile = props.getProperty("inputFile");
            String outputDir = props.getProperty("outputDir");
			int conflictAction =  Integer.parseInt(props.getProperty("conflictAction"));
    
	     // get a reference to the Web Service
            CMSAPI2WebServiceLocator wsLocator = new CMSAPI2WebServiceLocator(new FileProvider("./configs/apitestsuite_client_deploy.wsdd"));
            CMSAPI2Web cmsWeb = wsLocator.getCMSAPI2WebWrapped(new URL(webServiceUrl));
			
            
            // add the username/password into the webservice stub
            Stub stub = (Stub) cmsWeb;
            stub.setUsername(username);
            stub.setPassword(password);
			
			System.out.println("Importing Package!");
			cmsWeb.importPackage( inputFile , conflictAction);
      
			System.out.println("All done Importing Package!");
		}
        catch(Exception ex){
            System.out.println("Exception : " + ex);
        }
     }

 /**
     *Saves a file to the specified location
     *@param dir The directory path
     *@param fileName The filename
     *@param data The content to be saved
     *@throws IOException
     */
    public static void saveFile(String dir, String fileName, byte[] data) throws IOException{

            // make sure local dir exists, then save the byte array
            File resultDir = new File(dir);
            resultDir.mkdirs();
            File filepath = new File(dir, fileName);

            FileOutputStream fos = new FileOutputStream(filepath);
            fos.write(data);
            fos.flush();
            fos.close();

    }
}